const express = require("express");
const { Pool } = require("pg");

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL environment variable is not set.");
}

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === "production"
        ? { rejectUnauthorized: false }
        : false
});

app.use(express.json());
app.use(express.static("public"));

async function createTable() {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS feedback (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100),
                email VARCHAR(150),
                rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log("Feedback table ready.");
    } catch (error) {
        console.error("Database initialization error:", error);
    }
}

createTable();

app.post("/api/feedback", async (req, res) => {
    const { name, email, rating, message } = req.body;
    const numericRating = Number(rating);

    if (!message || !message.trim()) {
        return res.status(400).json({
            success: false,
            message: "Feedback message is required."
        });
    }

    if (!Number.isInteger(numericRating) || numericRating < 1 || numericRating > 5) {
        return res.status(400).json({
            success: false,
            message: "Please select a rating from 1 to 5."
        });
    }

    try {
        const result = await pool.query(
            `INSERT INTO feedback (name, email, rating, message)
             VALUES ($1, $2, $3, $4)
             RETURNING id`,
            [
                name?.trim() || null,
                email?.trim() || null,
                numericRating,
                message.trim()
            ]
        );

        res.json({
            success: true,
            message: "Thank you! Your feedback has been submitted.",
            id: result.rows[0].id
        });
    } catch (error) {
        console.error("Insert error:", error);
        res.status(500).json({
            success: false,
            message: "Unable to save feedback. Please try again."
        });
    }
});

app.get("/health", async (req, res) => {
    try {
        await pool.query("SELECT 1");
        res.json({ status: "ok", database: "connected" });
    } catch (error) {
        res.status(500).json({ status: "error", database: "disconnected" });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
